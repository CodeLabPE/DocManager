<?php
require_once ("conexao.php");
//include ('linkFramework.php');

  $nome = $_POST['nome'];
  $cpf = $_POST['cpf'];
  $sobrenome = $_POST['sobrenome'];
  $email = $_POST['email'];
  $instituicao = $_POST['instituicao'];
  $senha = $_POST['senha'];
  $perfil = $_POST['tp_perfil'];
  $status = $_POST['status'];
  $arquivo = $_FILES['arquivo'];


if (isset($_FILES['arquivo'])) {

$extensao = strtolower(substr($_FILES['arquivo']['name'], -4)); // pega a extensao do arquivo
$novo_nome = md5(time()) . $extensao; //define o nome do arquivo
$diretorio = "../upload/imagem_perfil/"; //define o diretorios para onde enviar o arquivo

move_uploaded_file($_FILES['arquivo']['tmp_name'], $diretorio.$novo_nome);

$sql_code = "UPDATE usuario SET (nome = '$nome', sobrenome = '$sobrenome', email = '$email', cpf = '$cpf', senha = '', sexo = '$sexo', perfil = '$perfil', status = '$status', arquivo = '$novo_nome', instituicao_id = '$instituicao', dataCadastro = '')";

  mysql_query($sql_code) or die(mysql_error());


  if(mysql_affected_rows($conexao) > 0)

       header('Location: ../usuarios.php');
//    echo' <script> window.alert("kkkk"); </script> ';

  else 

    echo "<p> Erro ao inserir no Banco de Dados </p>";

}

?>