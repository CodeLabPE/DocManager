<?php
  require_once ("conexao.php");
    $idUsuario = $_POST['var'];
    $idFoto = $_POST['foto'];
      $sql_code = "DELETE FROM advogado WHERE id = '$idUsuario' ";
        mysql_query($sql_code) or die(mysql_error());
        	unlink("../upload/imagem_perfil/$idFoto");
          		header('Location: ../advogados.php');
          		  mysql_close($conexao);
  ?>