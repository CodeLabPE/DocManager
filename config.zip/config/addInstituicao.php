<?php
  require_once ("conexao.php");

  $tipo = $_POST['tipo'];
  $nome = $_POST['nome'];
  $sigla = $_POST['sigla'];
  $email = $_POST['email'];
  $cep = $_POST['cep'];
  $endereco = $_POST['endereco'];
   $bairro = $_POST['bairro'];
    $cidade = $_POST['cidade'];
     $uf = $_POST['uf'];
      $obs = $_POST['obs'];
      $status = $_POST['status'];


  $sql_code = "INSERT INTO instituicao (tipo, nome, sigla, email, cep, endereco, bairro, cidade, uf, observacao, status, dataCadastro) VALUES ('$tipo', '$nome','$sigla','$email', '$cep','$endereco','$bairro','$cidade','$uf','$obs','$status', NOW())";
   
   mysql_query($sql_code) or die(mysql_error());
  echo 'Registro inserido com sucesso!'; 


//echo "<script>alert('Cadastro efetuado com sucesso!')</script>"

header('Location: ../instituicoes.php');


   if(mysql_affected_rows($conexao) > 0){

print "O formulario foi inserido com sucesso.";

   }
       

   else {

print "Não foi possível salvar o formulario na base de dados.";

   }

   mysql_close($conexao);
       
   
  ?>