<?php
require_once ("conexao.php");
//include ('linkFramework.php');

  $oab = $_POST['oab'];
  $nome = $_POST['nome'];
  $sobrenome = $_POST['sobrenome'];
  $email = $_POST['email'];
  $senha = $_POST['senha'];
  $sexo = $_POST['sexo'];
  $status = $_POST['status'];
  $arquivo = $_FILES['arquivo'];


if (isset($_FILES['arquivo'])) {

$extensao = strtolower(substr($_FILES['arquivo']['name'], -4)); // pega a extensao do arquivo
$novo_nome = md5(time()) . $extensao; //define o nome do arquivo
$diretorio = "../upload/imagem_perfil/"; //define o diretorios para onde enviar o arquivo

move_uploaded_file($_FILES['arquivo']['tmp_name'], $diretorio.$novo_nome);

$sql_code = "INSERT INTO advogado (oab, nome, sobrenome, email, senha, sexo, status, arquivo, dataCadastro ) VALUES ('$oab', '$nome', '$sobrenome', '$email', '$senha', '$sexo', '$status', '$novo_nome', NOW())";

  mysql_query($sql_code) or die(mysql_error());


  if(mysql_affected_rows($conexao) > 0)

       header('Location: ../advogados.php');
//    echo' <script> window.alert("kkkk"); </script> ';

  else 

    echo "<p> Erro ao inserir no Banco de Dados </p>";

}

?>