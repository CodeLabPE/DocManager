<?php
  $conexao = mysql_connect("127.0.0.1:3306", "root", "001132229");
   
  if($conexao)
  {
  $baseSelecionada = mysql_select_db("docmanager_db");
  if (!$baseSelecionada) {
      die ('Não foi possível conectar a base de dados: ' . mysql_error());
  } } else {
      die('Não conectado : ' . mysql_error());
  }
  ?>