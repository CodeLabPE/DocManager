<?php
require_once ("conexao.php");

  $prontuario = $_POST['pront'];
  $nome = $_POST['nome'];
  $nome_mae = $_POST['nome_mae'];
  $sexo = $_POST['sexo'];
  $regime = $_POST['regime'];
  $instituicao = $_POST['instituicao'];



$sql_code = "INSERT INTO detento (prontuario, nome, nome_mae, sexo, regime, instituicao_id, dataCadastro ) VALUES ('$prontuario', '$nome', '$nome_mae', '$sexo', '$regime','$instituicao', NOW())";

  mysql_query($sql_code) or die(mysql_error());


  if(mysql_affected_rows($conexao) > 0)

       header('Location: ../detentos.php');
//    echo' <script> window.alert("kkkk"); </script> ';

  else 

    echo "<p> Erro ao inserir no Banco de Dados </p>";

?>