<?php
  require("conexao.php");
   
//RECEBE PARÂMETRO  
$id = $_GET["id"];  

//EXIBE IMAGEM                                                                        
$sql = mysqli_query("SELECT img, img_tipo FROM usuario WHERE id = ".$id."");         

$row = mysqli_fetch_array($sql, MYSQLI_ASSOC);    
   $tipo   = $row["img_tipo"];                        
   $bytes  = $row["img"];                        
   //EXIBE IMAGEM                                 
   header("Content-type: ".$tipo."");             
   echo $bytes;                                   
?>